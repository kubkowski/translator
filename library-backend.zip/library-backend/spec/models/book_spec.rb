require 'spec_helper'

describe Book do
  pending "add some examples to (or delete) #{__FILE__}"
end
