require 'spec_helper'

describe PublishersController do

end
