require 'spec_helper'

describe BooksController do

end
