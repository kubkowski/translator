require 'spec_helper'

describe AuthorsController do

end
