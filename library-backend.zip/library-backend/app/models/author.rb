class Author < ActiveRecord::Base
end
