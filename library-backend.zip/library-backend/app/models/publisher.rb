class Publisher < ActiveRecord::Base
end
